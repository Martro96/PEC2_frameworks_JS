function multiplyBy10(array) {
  // your code here
}

function shiftRight(array) {
  // your code here
}

function onlyVowels(array) {
  // your code here
}

function doubleMatrix(array) {
  // your code here
}

module.exports = {
  multiplyBy10,
  shiftRight,
  onlyVowels,
  doubleMatrix
};
