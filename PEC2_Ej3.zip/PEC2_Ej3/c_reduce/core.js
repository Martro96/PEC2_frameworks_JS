function sum(array) {
  // your code here
}

function productAll(array) {
  // your code here
}

function objectify(array) {
  // your code here
}

function luckyNumbers(array) {
  // your code here
}

module.exports = {
  sum,
  productAll,
  objectify,
  luckyNumbers
};
