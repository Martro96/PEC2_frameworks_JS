function onlyEven(array) {
  // your code here
}

function onlyOneWord(array) {
  // your code here
}

function positiveRowsOnly(array) {
  // your code here
}

function allSameVowels(array) {
  // your code here
}

module.exports = {
  onlyEven,
  onlyOneWord,
  positiveRowsOnly,
  allSameVowels
};
